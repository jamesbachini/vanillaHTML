//import { utils } from './../core/utils.js';
import { core } from './../core/core.js';

window.vSettings = {
  brand: 'VanillaHTML',
}

core.init();
